from coinanalyse.colors import green, white, red, info, run, end
print ('''%s
  /\   _ _						 
 /--\  |  |  /_\   ||  \ /  ~  sss
/    \ |  | /   \  ||   /   &  e e   %sv1.0.4
%s''' % (green, white, end))